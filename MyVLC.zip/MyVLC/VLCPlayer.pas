﻿unit VLCPlayer;

interface

uses
  System.SysUtils, System.Classes, Winapi.Windows, Winapi.Messages, System.IOUtils,
  System.StrUtils, System.RegularExpressions;

type
  TVLCStreamType = (stAuto, stHLS, stSMIL, stMMS, stRTMP, stRTSP, stUDP, stRTP, stHTTP, stFile);
  TVLCEvent = procedure(Sender: TObject) of object;
  TVLCPositionChanged = procedure(Sender: TObject; Position: Single) of object;
  TVLCTimeChanged = procedure(Sender: TObject; Time: Int64) of object;
  TVLCBuffering = procedure(Sender: TObject; CachePercentage: Single) of object;

  TCustomVLCPlayer = class(TComponent)
  private
    FHandle: THandle;
    FInstance: Pointer;
    FMediaPlayer: Pointer;
    FMedia: Pointer;
    FOnPlay: TVLCEvent;
    FOnPause: TVLCEvent;
    FOnStop: TVLCEvent;
    FOnEndReached: TVLCEvent;
    FOnPositionChanged: TVLCPositionChanged;
    FOnTimeChanged: TVLCTimeChanged;
    FOnBuffering: TVLCBuffering;
    FVolume: Integer;
    FIsPlaying: Boolean;
    FLibVLC: HMODULE;
    FVLCInitialized: Boolean;
    FVLCPath: string;
    FLastError: string;
    FNetworkCaching: Integer;
    FStreamType: TVLCStreamType;

    // libvlc function pointers
    libvlc_new: function(argc: Integer; args: PPAnsiChar): Pointer; cdecl;
    libvlc_release: procedure(p_instance: Pointer); cdecl;
    libvlc_media_new_location: function(p_instance: Pointer; psz_mrl: PAnsiChar): Pointer; cdecl;
    libvlc_media_new_path: function(p_instance: Pointer; path: PAnsiChar): Pointer; cdecl;
    libvlc_media_release: procedure(p_media: Pointer); cdecl;
    libvlc_media_player_new_from_media: function(p_media: Pointer): Pointer; cdecl;
    libvlc_media_player_release: procedure(p_media_player: Pointer); cdecl;
    libvlc_media_player_set_hwnd: procedure(p_media_player: Pointer; drawable: THandle); cdecl;
    libvlc_media_player_play: function(p_media_player: Pointer): Integer; cdecl;
    libvlc_media_player_pause: procedure(p_media_player: Pointer); cdecl;
    libvlc_media_player_stop: procedure(p_media_player: Pointer); cdecl;
    libvlc_media_player_set_pause: procedure(p_media_player: Pointer; do_pause: Integer); cdecl;
    libvlc_media_player_is_playing: function(p_media_player: Pointer): Integer; cdecl;
    libvlc_media_player_get_position: function(p_media_player: Pointer): Single; cdecl;
    libvlc_media_player_set_position: procedure(p_media_player: Pointer; position: Single); cdecl;
    libvlc_media_player_get_time: function(p_media_player: Pointer): Int64; cdecl;
    libvlc_media_player_set_time: procedure(p_media_player: Pointer; time: Int64); cdecl;
    libvlc_audio_set_volume: procedure(p_media_player: Pointer; volume: Integer); cdecl;
    libvlc_audio_get_volume: function(p_media_player: Pointer): Integer; cdecl;
    libvlc_media_player_get_length: function(p_media_player: Pointer): Int64; cdecl;
    libvlc_media_player_will_play: function(p_media_player: Pointer): Integer; cdecl;
    libvlc_media_add_option: procedure(p_media: Pointer; psz_options: PAnsiChar); cdecl;
    libvlc_media_parse: procedure(p_media: Pointer); cdecl;

    procedure SetHandle(const Value: THandle);
    procedure SetVolume(const Value: Integer);
    function GetPosition: Single;
    procedure SetPosition(const Value: Single);
    function GetTime: Int64;
    procedure SetTime(const Value: Int64);
    function GetLength: Int64;
    function GetIsPlaying: Boolean;
    function GetVLCInitialized: Boolean;
    procedure SetVLCPath(const Value: string);
    function GetLastError: string;
    procedure SetNetworkCaching(const Value: Integer);
    procedure SetStreamType(const Value: TVLCStreamType);
  protected
    procedure LoadVLCFunctions;
    procedure LoadLibVLC;
    procedure AutoDetectVLCPath;
    procedure InitializeVLC;
    procedure DoPlay;
    procedure DoPause;
    procedure DoStop;
    procedure DoEndReached;
    procedure DoPositionChanged(Position: Single);
    procedure DoTimeChanged(Time: Int64);
    procedure DoBuffering(CachePercentage: Single);
    procedure CheckVLCInitialized;
    function DetectStreamType(const URL: string): TVLCStreamType;
    function BuildVLCOptions(const URL: string; StreamType: TVLCStreamType): TArray<string>;
    function CreateMediaWithOptions(const URL: string; StreamType: TVLCStreamType): Pointer;
  public
    constructor Create(AOwner: TComponent); override;
    destructor Destroy; override;

    function Initialize: Boolean;
    procedure Play;
    procedure Pause;
    procedure Stop;

    function PlayURL(const URL: string): Boolean; overload;
    function PlayURL(const URL: string; StreamType: TVLCStreamType): Boolean; overload;
    function PlayFile(const FileName: string): Boolean;
    function PlayIPTV(const URL: string): Boolean; overload;
    function PlayIPTV(const URL: string; StreamType: TVLCStreamType): Boolean; overload;

    // Специализированные методы для разных типов потоков
    function PlayHLS(const URL: string): Boolean;
    function PlaySMIL(const URL: string): Boolean;
    function PlayMMS(const URL: string): Boolean;
    function PlayRTMP(const URL: string): Boolean;
    function PlayRTSP(const URL: string): Boolean;
    function PlayUDP(const URL: string): Boolean;
    function PlayRTP(const URL: string): Boolean;

    property Handle: THandle read FHandle write SetHandle;
    property Position: Single read GetPosition write SetPosition;
    property Time: Int64 read GetTime write SetTime;
    property Length: Int64 read GetLength;
    property IsPlaying: Boolean read GetIsPlaying;
    property VLCInitialized: Boolean read GetVLCInitialized;
    property VLCPath: string read FVLCPath write SetVLCPath;
    property LastError: string read GetLastError;
    property NetworkCaching: Integer read FNetworkCaching write SetNetworkCaching default 1000;
    property StreamType: TVLCStreamType read FStreamType write SetStreamType default stAuto;
  published
    property Volume: Integer read FVolume write SetVolume default 50;
    property OnPlay: TVLCEvent read FOnPlay write FOnPlay;
    property OnPause: TVLCEvent read FOnPause write FOnPause;
    property OnStop: TVLCEvent read FOnStop write FOnStop;
    property OnEndReached: TVLCEvent read FOnEndReached write FOnEndReached;
    property OnPositionChanged: TVLCPositionChanged read FOnPositionChanged write FOnPositionChanged;
    property OnTimeChanged: TVLCTimeChanged read FOnTimeChanged write FOnTimeChanged;
    property OnBuffering: TVLCBuffering read FOnBuffering write FOnBuffering;
  end;

  TVLCPlayer = class(TCustomVLCPlayer)
  published
    property Handle;
    property Volume;
    property VLCPath;
    property NetworkCaching;
    property StreamType;
    property OnPlay;
    property OnPause;
    property OnStop;
    property OnEndReached;
    property OnPositionChanged;
    property OnTimeChanged;
    property OnBuffering;
  end;

procedure Register;

implementation

const
  LIBVLC_DLL = 'libvlc.dll';

procedure Register;
begin
  RegisterComponents('Video', [TVLCPlayer]);
end;

{ TCustomVLCPlayer }

constructor TCustomVLCPlayer.Create(AOwner: TComponent);
begin
  inherited Create(AOwner);
  FVolume := 50;
  FIsPlaying := False;
  FVLCInitialized := False;
  FLastError := '';
  FNetworkCaching := 1000;
  FStreamType := stAuto;

  // Автоматически определяем путь к VLC
  AutoDetectVLCPath;

  // Не инициализируем VLC в режиме дизайна
  if not (csDesigning in ComponentState) then
  begin
    Initialize;
  end;
end;

destructor TCustomVLCPlayer.Destroy;
begin
  Stop;
  if FVLCInitialized then
  begin
    if Assigned(FMediaPlayer) then
    begin
      libvlc_media_player_release(FMediaPlayer);
      FMediaPlayer := nil;
    end;
    if Assigned(FMedia) then
    begin
      libvlc_media_release(FMedia);
      FMedia := nil;
    end;
    if Assigned(FInstance) then
    begin
      libvlc_release(FInstance);
      FInstance := nil;
    end;
  end;

  if FLibVLC <> 0 then
  begin
    FreeLibrary(FLibVLC);
    FLibVLC := 0;
  end;

  inherited Destroy;
end;

procedure TCustomVLCPlayer.AutoDetectVLCPath;
var
  AppPath, TestPath: string;
  PossiblePaths: TArray<string>;
  Path: string;
begin
  AppPath := ExtractFilePath(ParamStr(0));

  // ПРИОРИТЕТ 1: Папка с программой и её подпапки
  PossiblePaths := [
    AppPath,  // №1 - папка с exe
    AppPath + 'vlc\',
    AppPath + 'VLC\',
    AppPath + 'libvlc\',
    // Системные пути VLC
    'C:\Program Files\VideoLAN\VLC\',
    'C:\Program Files (x86)\VideoLAN\VLC\',
    GetEnvironmentVariable('PROGRAMFILES') + '\VideoLAN\VLC\',
    GetEnvironmentVariable('PROGRAMFILES(X86)') + '\VideoLAN\VLC\'
  ];

  FVLCPath := '';
  for Path in PossiblePaths do
  begin
    TestPath := IncludeTrailingPathDelimiter(Path);
    if FileExists(TestPath + LIBVLC_DLL) then
    begin
      FVLCPath := TestPath;
      FLastError := 'VLC found at: ' + FVLCPath;
      Break;
    end;
  end;

  if FVLCPath = '' then
    FLastError := 'VLC not found in any standard location';
end;

procedure TCustomVLCPlayer.SetVLCPath(const Value: string);
begin
  if FVLCPath <> Value then
  begin
    FVLCPath := Value;
    if FVLCInitialized then
    begin
      Stop;
      AutoDetectVLCPath;
      Initialize;
    end;
  end;
end;

procedure TCustomVLCPlayer.SetNetworkCaching(const Value: Integer);
begin
  if FNetworkCaching <> Value then
  begin
    FNetworkCaching := Value;
  end;
end;

procedure TCustomVLCPlayer.SetStreamType(const Value: TVLCStreamType);
begin
  if FStreamType <> Value then
  begin
    FStreamType := Value;
  end;
end;

function TCustomVLCPlayer.Initialize: Boolean;
begin
  Result := False;
  try
    LoadLibVLC;
    Result := FVLCInitialized;
  except
    on E: Exception do
    begin
      FLastError := E.Message;
      if not (csDesigning in ComponentState) then
        raise;
    end;
  end;
end;

procedure TCustomVLCPlayer.LoadLibVLC;
var
  FullPath, OldCurrentDir: string;
  PluginsPath: string;
begin
  if FVLCInitialized then Exit;

  // Определяем полный путь к DLL
  if FVLCPath <> '' then
    FullPath := FVLCPath + LIBVLC_DLL
  else
    FullPath := LIBVLC_DLL;

  // Сохраняем текущую директорию
  OldCurrentDir := GetCurrentDir;

  try
    // КРИТИЧЕСКИ ВАЖНО: Устанавливаем текущую директорию в папку с VLC
    if FVLCPath <> '' then
    begin
      SetCurrentDir(FVLCPath);
    end;

    // Устанавливаем путь к плагинам через переменные окружения
    if FVLCPath <> '' then
    begin
      PluginsPath := FVLCPath + 'plugins\';
      SetEnvironmentVariable('VLC_PLUGIN_PATH', PChar(PluginsPath));
      // Дублируем для надежности
      SetEnvironmentVariable('VLC_PLUGIN_PATH', PChar(PluginsPath));
    end;

    // Пытаемся загрузить библиотеку
    FLibVLC := LoadLibrary(PChar(FullPath));

    if FLibVLC = 0 then
    begin
      // Если не удалось загрузить по полному пути, пробуем просто по имени
      FLibVLC := LoadLibrary(PChar(LIBVLC_DLL));
      if FLibVLC <> 0 then
        FLastError := 'VLC loaded from system path or current directory'
      else
      begin
        FLastError := 'Cannot load VLC from: ' + FullPath +
                     '. Error code: ' + GetLastError +
                     '. Current dir: ' + GetCurrentDir;
        Exit;
      end;
    end;

    LoadVLCFunctions;
    InitializeVLC;

  finally
    // Восстанавливаем оригинальную директорию
    SetCurrentDir(OldCurrentDir);
  end;
end;

procedure TCustomVLCPlayer.LoadVLCFunctions;
begin
  @libvlc_new := GetProcAddress(FLibVLC, 'libvlc_new');
  @libvlc_release := GetProcAddress(FLibVLC, 'libvlc_release');
  @libvlc_media_new_location := GetProcAddress(FLibVLC, 'libvlc_media_new_location');
  @libvlc_media_new_path := GetProcAddress(FLibVLC, 'libvlc_media_new_path');
  @libvlc_media_release := GetProcAddress(FLibVLC, 'libvlc_media_release');
  @libvlc_media_player_new_from_media := GetProcAddress(FLibVLC, 'libvlc_media_player_new_from_media');
  @libvlc_media_player_release := GetProcAddress(FLibVLC, 'libvlc_media_player_release');
  @libvlc_media_player_set_hwnd := GetProcAddress(FLibVLC, 'libvlc_media_player_set_hwnd');
  @libvlc_media_player_play := GetProcAddress(FLibVLC, 'libvlc_media_player_play');
  @libvlc_media_player_pause := GetProcAddress(FLibVLC, 'libvlc_media_player_pause');
  @libvlc_media_player_stop := GetProcAddress(FLibVLC, 'libvlc_media_player_stop');
  @libvlc_media_player_set_pause := GetProcAddress(FLibVLC, 'libvlc_media_player_set_pause');
  @libvlc_media_player_is_playing := GetProcAddress(FLibVLC, 'libvlc_media_player_is_playing');
  @libvlc_media_player_get_position := GetProcAddress(FLibVLC, 'libvlc_media_player_get_position');
  @libvlc_media_player_set_position := GetProcAddress(FLibVLC, 'libvlc_media_player_set_position');
  @libvlc_media_player_get_time := GetProcAddress(FLibVLC, 'libvlc_media_player_get_time');
  @libvlc_media_player_set_time := GetProcAddress(FLibVLC, 'libvlc_media_player_set_time');
  @libvlc_audio_set_volume := GetProcAddress(FLibVLC, 'libvlc_audio_set_volume');
  @libvlc_audio_get_volume := GetProcAddress(FLibVLC, 'libvlc_audio_get_volume');
  @libvlc_media_player_get_length := GetProcAddress(FLibVLC, 'libvlc_media_player_get_length');
  @libvlc_media_player_will_play := GetProcAddress(FLibVLC, 'libvlc_media_player_will_play');
  @libvlc_media_add_option := GetProcAddress(FLibVLC, 'libvlc_media_add_option');
  @libvlc_media_parse := GetProcAddress(FLibVLC, 'libvlc_media_parse');

  if not Assigned(libvlc_new) then
  begin
    FLastError := 'Required VLC functions not found';
    Exit;
  end;
end;

procedure TCustomVLCPlayer.InitializeVLC;
var
  Args: array[0..10] of PAnsiChar;
  ArgCount: Integer;
  PluginsPath: string;
begin
  if FVLCInitialized then Exit;

  try
    // Подготавливаем аргументы для VLC
    ArgCount := 0;

    Args[ArgCount] := PAnsiChar('--intf=dummy'); Inc(ArgCount);
    Args[ArgCount] := PAnsiChar('--no-video-title-show'); Inc(ArgCount);
    Args[ArgCount] := PAnsiChar('--no-stats'); Inc(ArgCount);
    Args[ArgCount] := PAnsiChar('--avcodec-hw=any'); Inc(ArgCount);
    Args[ArgCount] := PAnsiChar('--network-caching=' + IntToStr(FNetworkCaching)); Inc(ArgCount);

    // КРИТИЧЕСКИ ВАЖНО: Явно указываем путь к плагинам
    if FVLCPath <> '' then
    begin
      PluginsPath := '--plugin-path=' + FVLCPath + 'plugins';
      Args[ArgCount] := PAnsiChar(AnsiString(PluginsPath)); Inc(ArgCount);
    end;

    // Дополнительные опции для стабильности
    Args[ArgCount] := PAnsiChar('--no-audio'); Inc(ArgCount); // Временно отключаем аудио для отладки
    Args[ArgCount] := PAnsiChar('--verbose=2'); Inc(ArgCount); // Включаем логи для отладки

    Args[ArgCount] := nil;

    FInstance := libvlc_new(ArgCount, @Args[0]);
    FVLCInitialized := Assigned(FInstance);

    if not FVLCInitialized then
      FLastError := 'Failed to create VLC instance'
    else
      FLastError := 'VLC successfully initialized';

  except
    on E: Exception do
    begin
      FLastError := 'VLC initialization error: ' + E.Message;
      FVLCInitialized := False;
    end;
  end;
end;

function TCustomVLCPlayer.DetectStreamType(const URL: string): TVLCStreamType;
var
  LowerURL: string;
begin
  LowerURL := LowerCase(URL);

  if LowerURL.Contains('.m3u8') or LowerURL.Contains('/hls/') or LowerURL.Contains('hls_') then
    Result := stHLS
  else if LowerURL.Contains('.smil') or LowerURL.Contains('/smil:') then
    Result := stSMIL
  else if LowerURL.StartsWith('mms://') or LowerURL.StartsWith('mmst://') or LowerURL.StartsWith('mmsh://') then
    Result := stMMS
  else if LowerURL.StartsWith('rtmp://') or LowerURL.Contains('/rtmp/') then
    Result := stRTMP
  else if LowerURL.StartsWith('rtsp://') then
    Result := stRTSP
  else if LowerURL.StartsWith('udp://') or LowerURL.StartsWith('udp://@') then
    Result := stUDP
  else if LowerURL.StartsWith('rtp://') then
    Result := stRTP
  else if LowerURL.StartsWith('http://') or LowerURL.StartsWith('https://') then
    Result := stHTTP
  else if FileExists(URL) then
    Result := stFile
  else
    Result := stAuto;
end;

function TCustomVLCPlayer.BuildVLCOptions(const URL: string; StreamType: TVLCStreamType): TArray<string>;
var
  Options: TStringList;
  DetectedType: TVLCStreamType;
begin
  Options := TStringList.Create;
  try
    // Определяем тип потока если указан Auto
    if StreamType = stAuto then
      DetectedType := DetectStreamType(URL)
    else
      DetectedType := StreamType;

    // Базовые опции для всех потоков
    Options.Add(':network-caching=' + IntToStr(FNetworkCaching));
    Options.Add(':live-caching=' + IntToStr(FNetworkCaching));
    Options.Add(':file-caching=' + IntToStr(FNetworkCaching));
    Options.Add(':sout-mux-caching=' + IntToStr(FNetworkCaching));
    Options.Add(':clock-jitter=0');
    Options.Add(':clock-synchro=0');

    // Специфические опции для разных типов потоков
    case DetectedType of
      stHLS:
        begin
          Options.Add(':hls-segment-threads=3');
          Options.Add(':hls-timeout=30');
          Options.Add(':hls-bitrate-adaptive');
          Options.Add(':http-reconnect=true');
          Options.Add(':http-continuous');
        end;

      stSMIL:
        begin
          Options.Add(':smil-active-item');
          Options.Add(':smil-forward');
          Options.Add(':sout-smil-timeout=10');
        end;

      stMMS:
        begin
          Options.Add(':mms-timeout=30');
          Options.Add(':mms-caching=2000');
          Options.Add(':mmsh-rate=10000000');
        end;

      stRTMP:
        begin
          Options.Add(':rtmp-live');
          Options.Add(':rtmp-timeout=30');
          Options.Add(':rtmp-swfverify');
          Options.Add(':rtmp-buffer=3000');
        end;

      stRTSP:
        begin
          Options.Add(':rtsp-tcp');
          Options.Add(':rtsp-timeout=30');
          Options.Add(':rtsp-http-port=80');
          Options.Add(':rtsp-http-caching=3000');
        end;

      stUDP:
        begin
          Options.Add(':udp-timeout=60000000');
          Options.Add(':udp-caching=1000');
        end;

      stRTP:
        begin
          Options.Add(':rtp-max-dropout=1000');
          Options.Add(':rtp-max-misorder=1000');
          Options.Add(':rtp-sync=0');
        end;

      stHTTP:
        begin
          Options.Add(':http-user-agent="VLC/3.0"');
          Options.Add(':http-referrer=""');
          Options.Add(':http-forward-cookies');
          Options.Add(':http-continuous');
        end;
    end;

    // Дополнительные опции для улучшения стабильности
    Options.Add(':avcodec-hw=any');
    Options.Add(':drop-late-frames');
    Options.Add(':skip-frames');
    Options.Add(':codec=avcodec,none');

    Result := Options.ToStringArray;

  finally
    Options.Free;
  end;
end;

function TCustomVLCPlayer.CreateMediaWithOptions(const URL: string; StreamType: TVLCStreamType): Pointer;
var
  Options: TArray<string>;
  MRL: UTF8String;
  i: Integer;
begin
  Result := nil;

  if not FVLCInitialized then
    Exit;

  // Создаем media объект
  MRL := UTF8String(URL);
  if StreamType = stFile then
    Result := libvlc_media_new_path(FInstance, PAnsiChar(MRL))
  else
    Result := libvlc_media_new_location(FInstance, PAnsiChar(MRL));

  if not Assigned(Result) then
    Exit;

  // Добавляем опции
  Options := BuildVLCOptions(URL, StreamType);
  for i := 0 to High(Options) do
  begin
    if Options[i] <> '' then
      libvlc_media_add_option(Result, PAnsiChar(UTF8String(Options[i])));
  end;

  // Парсим media для получения информации
  libvlc_media_parse(Result);
end;

function TCustomVLCPlayer.PlayURL(const URL: string): Boolean;
begin
  Result := PlayURL(URL, FStreamType);
end;

function TCustomVLCPlayer.PlayURL(const URL: string; StreamType: TVLCStreamType): Boolean;
begin
  Result := False;
  CheckVLCInitialized;

  if not FVLCInitialized then
    Exit;

  // Останавливаем предыдущее воспроизведение
  Stop;

  // Освобождаем предыдущие ресурсы
  if Assigned(FMediaPlayer) then
  begin
    libvlc_media_player_release(FMediaPlayer);
    FMediaPlayer := nil;
  end;
  if Assigned(FMedia) then
  begin
    libvlc_media_release(FMedia);
    FMedia := nil;
  end;

  // Создаем media с опциями
  FMedia := CreateMediaWithOptions(URL, StreamType);
  if not Assigned(FMedia) then
  begin
    FLastError := 'Failed to create media for URL: ' + URL;
    Exit;
  end;

  // Создаем media player
  FMediaPlayer := libvlc_media_player_new_from_media(FMedia);
  if not Assigned(FMediaPlayer) then
  begin
    libvlc_media_release(FMedia);
    FMedia := nil;
    FLastError := 'Failed to create media player';
    Exit;
  end;

  // Устанавливаем окно вывода
  if FHandle <> 0 then
    libvlc_media_player_set_hwnd(FMediaPlayer, FHandle);

  // Устанавливаем громкость
  libvlc_audio_set_volume(FMediaPlayer, FVolume);

  // Запускаем воспроизведение
  Play;
  Result := True;
end;

function TCustomVLCPlayer.PlayFile(const FileName: string): Boolean;
begin
  Result := PlayURL(FileName, stFile);
end;

function TCustomVLCPlayer.PlayIPTV(const URL: string): Boolean;
begin
  Result := PlayURL(URL, stAuto);
end;

function TCustomVLCPlayer.PlayIPTV(const URL: string; StreamType: TVLCStreamType): Boolean;
begin
  Result := PlayURL(URL, StreamType);
end;

// Специализированные методы для разных типов потоков

function TCustomVLCPlayer.PlayHLS(const URL: string): Boolean;
begin
  Result := PlayURL(URL, stHLS);
end;

function TCustomVLCPlayer.PlaySMIL(const URL: string): Boolean;
begin
  Result := PlayURL(URL, stSMIL);
end;

function TCustomVLCPlayer.PlayMMS(const URL: string): Boolean;
begin
  Result := PlayURL(URL, stMMS);
end;

function TCustomVLCPlayer.PlayRTMP(const URL: string): Boolean;
begin
  Result := PlayURL(URL, stRTMP);
end;

function TCustomVLCPlayer.PlayRTSP(const URL: string): Boolean;
begin
  Result := PlayURL(URL, stRTSP);
end;

function TCustomVLCPlayer.PlayUDP(const URL: string): Boolean;
begin
  Result := PlayURL(URL, stUDP);
end;

function TCustomVLCPlayer.PlayRTP(const URL: string): Boolean;
begin
  Result := PlayURL(URL, stRTP);
end;

// Базовые методы управления

procedure TCustomVLCPlayer.Play;
begin
  CheckVLCInitialized;
  if FVLCInitialized and Assigned(FMediaPlayer) then
  begin
    libvlc_media_player_play(FMediaPlayer);
    FIsPlaying := True;
    DoPlay;
  end;
end;

procedure TCustomVLCPlayer.Pause;
begin
  if FVLCInitialized and Assigned(FMediaPlayer) then
  begin
    libvlc_media_player_pause(FMediaPlayer);
    FIsPlaying := False;
    DoPause;
  end;
end;

procedure TCustomVLCPlayer.Stop;
begin
  if FVLCInitialized and Assigned(FMediaPlayer) then
  begin
    libvlc_media_player_stop(FMediaPlayer);
    FIsPlaying := False;
    DoStop;
  end;
end;

// Остальные методы (Get/Set свойства)

procedure TCustomVLCPlayer.SetHandle(const Value: THandle);
begin
  if FHandle <> Value then
  begin
    FHandle := Value;
    if FVLCInitialized and Assigned(FMediaPlayer) and (FHandle <> 0) then
      libvlc_media_player_set_hwnd(FMediaPlayer, FHandle);
  end;
end;

procedure TCustomVLCPlayer.SetVolume(const Value: Integer);
begin
  if FVolume <> Value then
  begin
    FVolume := Value;
    if FVLCInitialized and Assigned(FMediaPlayer) then
      libvlc_audio_set_volume(FMediaPlayer, FVolume);
  end;
end;

function TCustomVLCPlayer.GetPosition: Single;
begin
  if FVLCInitialized and Assigned(FMediaPlayer) then
    Result := libvlc_media_player_get_position(FMediaPlayer)
  else
    Result := 0;
end;

procedure TCustomVLCPlayer.SetPosition(const Value: Single);
begin
  if FVLCInitialized and Assigned(FMediaPlayer) then
    libvlc_media_player_set_position(FMediaPlayer, Value);
end;

function TCustomVLCPlayer.GetTime: Int64;
begin
  if FVLCInitialized and Assigned(FMediaPlayer) then
    Result := libvlc_media_player_get_time(FMediaPlayer)
  else
    Result := 0;
end;

procedure TCustomVLCPlayer.SetTime(const Value: Int64);
begin
  if FVLCInitialized and Assigned(FMediaPlayer) then
    libvlc_media_player_set_time(FMediaPlayer, Value);
end;

function TCustomVLCPlayer.GetLength: Int64;
begin
  if FVLCInitialized and Assigned(FMediaPlayer) then
    Result := libvlc_media_player_get_length(FMediaPlayer)
  else
    Result := 0;
end;

function TCustomVLCPlayer.GetIsPlaying: Boolean;
begin
  if FVLCInitialized and Assigned(FMediaPlayer) then
    Result := libvlc_media_player_is_playing(FMediaPlayer) <> 0
  else
    Result := False;
end;

function TCustomVLCPlayer.GetVLCInitialized: Boolean;
begin
  Result := FVLCInitialized;
end;

function TCustomVLCPlayer.GetLastError: string;
begin
  Result := FLastError;
end;

procedure TCustomVLCPlayer.CheckVLCInitialized;
begin
  if not FVLCInitialized and not (csDesigning in ComponentState) then
  begin
    if not Initialize then
      raise Exception.Create('VLC not initialized: ' + FLastError);
  end;
end;

// Обработчики событий

procedure TCustomVLCPlayer.DoPlay;
begin
  if Assigned(FOnPlay) then
    FOnPlay(Self);
end;

procedure TCustomVLCPlayer.DoPause;
begin
  if Assigned(FOnPause) then
    FOnPause(Self);
end;

procedure TCustomVLCPlayer.DoStop;
begin
  if Assigned(FOnStop) then
    FOnStop(Self);
end;

procedure TCustomVLCPlayer.DoEndReached;
begin
  if Assigned(FOnEndReached) then
    FOnEndReached(Self);
end;

procedure TCustomVLCPlayer.DoPositionChanged(Position: Single);
begin
  if Assigned(FOnPositionChanged) then
    FOnPositionChanged(Self, Position);
end;

procedure TCustomVLCPlayer.DoTimeChanged(Time: Int64);
begin
  if Assigned(FOnTimeChanged) then
    FOnTimeChanged(Self, Time);
end;

procedure TCustomVLCPlayer.DoBuffering(CachePercentage: Single);
begin
  if Assigned(FOnBuffering) then
    FOnBuffering(Self, CachePercentage);
end;

end.
