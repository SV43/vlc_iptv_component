﻿unit VLCPlayer;

interface

uses
  System.SysUtils, System.Classes, Winapi.Windows, Winapi.Messages, System.IOUtils,
  System.StrUtils, System.RegularExpressions, System.Net.HttpClient;

type
  TVLCStreamType = (stAuto, stHLS, stSMIL, stMMS, stRTMP, stRTSP, stUDP, stRTP, stHTTP, stFile);
  TVLCEvent = procedure(Sender: TObject) of object;
  TVLCPositionChanged = procedure(Sender: TObject; Position: Single) of object;
  TVLCTimeChanged = procedure(Sender: TObject; Time: Int64) of object;
  TVLCBuffering = procedure(Sender: TObject; CachePercentage: Single) of object;

  TCustomVLCPlayer = class(TComponent)
  private
    FHandle: THandle;
    FInstance: Pointer;
    FMediaPlayer: Pointer;
    FMedia: Pointer;
    FOnPlay: TVLCEvent;
    FOnPause: TVLCEvent;
    FOnStop: TVLCEvent;
    FOnEndReached: TVLCEvent;
    FOnPositionChanged: TVLCPositionChanged;
    FOnTimeChanged: TVLCTimeChanged;
    FOnBuffering: TVLCBuffering;
    FVolume: Integer;
    FIsPlaying: Boolean;
    FLibVLC: HMODULE;
    FVLCInitialized: Boolean;
    FVLCPath: string;
    FLastError: string;
    FNetworkCaching: Integer;
    FStreamType: TVLCStreamType;
    FBaseURL: string;
    FUserAgent: string;

    // libvlc function pointers
    libvlc_new: function(argc: Integer; args: PPAnsiChar): Pointer; cdecl;
    libvlc_release: procedure(p_instance: Pointer); cdecl;
    libvlc_media_new_location: function(p_instance: Pointer; psz_mrl: PAnsiChar): Pointer; cdecl;
    libvlc_media_new_path: function(p_instance: Pointer; path: PAnsiChar): Pointer; cdecl;
    libvlc_media_release: procedure(p_media: Pointer); cdecl;
    libvlc_media_player_new_from_media: function(p_media: Pointer): Pointer; cdecl;
    libvlc_media_player_release: procedure(p_media_player: Pointer); cdecl;
    libvlc_media_player_set_hwnd: procedure(p_media_player: Pointer; drawable: THandle); cdecl;
    libvlc_media_player_play: function(p_media_player: Pointer): Integer; cdecl;
    libvlc_media_player_pause: procedure(p_media_player: Pointer); cdecl;
    libvlc_media_player_stop: procedure(p_media_player: Pointer); cdecl;
    libvlc_media_player_set_pause: procedure(p_media_player: Pointer; do_pause: Integer); cdecl;
    libvlc_media_player_is_playing: function(p_media_player: Pointer): Integer; cdecl;
    libvlc_media_player_get_position: function(p_media_player: Pointer): Single; cdecl;
    libvlc_media_player_set_position: procedure(p_media_player: Pointer; position: Single); cdecl;
    libvlc_media_player_get_time: function(p_media_player: Pointer): Int64; cdecl;
    libvlc_media_player_set_time: procedure(p_media_player: Pointer; time: Int64); cdecl;
    libvlc_audio_set_volume: procedure(p_media_player: Pointer; volume: Integer); cdecl;
    libvlc_audio_get_volume: function(p_media_player: Pointer): Integer; cdecl;
    libvlc_media_player_get_length: function(p_media_player: Pointer): Int64; cdecl;
    libvlc_media_player_will_play: function(p_media_player: Pointer): Integer; cdecl;
    libvlc_media_add_option: procedure(p_media: Pointer; psz_options: PAnsiChar); cdecl;
    libvlc_media_parse: procedure(p_media: Pointer); cdecl;

    procedure SetHandle(const Value: THandle);
    procedure SetVolume(const Value: Integer);
    function GetPosition: Single;
    procedure SetPosition(const Value: Single);
    function GetTime: Int64;
    procedure SetTime(const Value: Int64);
    function GetLength: Int64;
    function GetIsPlaying: Boolean;
    function GetVLCInitialized: Boolean;
    procedure SetVLCPath(const Value: string);
    function GetLastError: string;
    procedure SetNetworkCaching(const Value: Integer);
    procedure SetStreamType(const Value: TVLCStreamType);
  protected
    procedure LoadVLCFunctions;
    function LoadLibVLC: Boolean;
    procedure AutoDetectVLCPath;
    function InitializeVLC: Boolean;
    procedure DoPlay;
    procedure DoPause;
    procedure DoStop;
    procedure DoEndReached;
    procedure DoPositionChanged(Position: Single);
    procedure DoTimeChanged(Time: Int64);
    procedure DoBuffering(CachePercentage: Single);
    procedure CheckVLCInitialized;
    function DetectStreamType(const URL: string): TVLCStreamType;
    function BuildVLCOptions(const URL: string; StreamType: TVLCStreamType): TArray<string>;
    function CreateMediaWithOptions(const URL: string; StreamType: TVLCStreamType): Pointer;

    function ProcessHLSContent(const URL: string): string;
    function ProcessSMILContent(const URL: string): string;
    function ResolveRelativeURL(const BaseURL, RelativeURL: string): string;
    function DownloadContent(const URL: string): string;
    function FixM3U8Links(const Content, BaseURL: string): string;
    function FixSMILLinks(const Content, BaseURL: string): string;
    function ExtractBaseURL(const URL: string): string;

    function CheckVLCFilesExist: Boolean;
    function GetVLCVersionInfo: string;
  public
    constructor Create(AOwner: TComponent); override;
    destructor Destroy; override;

    function Initialize: Boolean;
    procedure Play;
    procedure Pause;
    procedure Stop;

    function PlayURL(const URL: string): Boolean; overload;
    function PlayURL(const URL: string; StreamType: TVLCStreamType): Boolean; overload;
    function PlayFile(const FileName: string): Boolean;
    function PlayIPTV(const URL: string): Boolean; overload;
    function PlayIPTV(const URL: string; StreamType: TVLCStreamType): Boolean; overload;

    function PlayHLS(const URL: string): Boolean;
    function PlaySMIL(const URL: string): Boolean;
    function PlayMMS(const URL: string): Boolean;
    function PlayRTMP(const URL: string): Boolean;
    function PlayRTSP(const URL: string): Boolean;
    function PlayUDP(const URL: string): Boolean;
    function PlayRTP(const URL: string): Boolean;

    function GetDebugInfo: string;
    function TestVLCInstallation: Boolean;

    property Handle: THandle read FHandle write SetHandle;
    property Position: Single read GetPosition write SetPosition;
    property Time: Int64 read GetTime write SetTime;
    property IsPlaying: Boolean read GetIsPlaying;
    property VLCInitialized: Boolean read GetVLCInitialized;
    property VLCPath: string read FVLCPath write SetVLCPath;
    property LastError: string read GetLastError;
    property NetworkCaching: Integer read FNetworkCaching write SetNetworkCaching default 1000;
    property StreamType: TVLCStreamType read FStreamType write SetStreamType default stAuto;
  published
    property Volume: Integer read FVolume write SetVolume default 50;
    property OnPlay: TVLCEvent read FOnPlay write FOnPlay;
    property OnPause: TVLCEvent read FOnPause write FOnPause;
    property OnStop: TVLCEvent read FOnStop write FOnStop;
    property OnEndReached: TVLCEvent read FOnEndReached write FOnEndReached;
    property OnPositionChanged: TVLCPositionChanged read FOnPositionChanged write FOnPositionChanged;
    property OnTimeChanged: TVLCTimeChanged read FOnTimeChanged write FOnTimeChanged;
    property OnBuffering: TVLCBuffering read FOnBuffering write FOnBuffering;
  end;

  TVLCPlayer = class(TCustomVLCPlayer)
  published
    property Handle;
    property Volume;
    property VLCPath;
    property NetworkCaching;
    property StreamType;
    property OnPlay;
    property OnPause;
    property OnStop;
    property OnEndReached;
    property OnPositionChanged;
    property OnTimeChanged;
    property OnBuffering;
  end;

procedure Register;

implementation

const
  LIBVLC_DLL = 'libvlc.dll';

procedure Register;
begin
  RegisterComponents('Video', [TVLCPlayer]);
end;

{ TCustomVLCPlayer }

constructor TCustomVLCPlayer.Create(AOwner: TComponent);
begin
  inherited Create(AOwner);
  FVolume := 50;
  FIsPlaying := False;
  FVLCInitialized := False;
  FLastError := '';
  FNetworkCaching := 1000;
  FStreamType := stAuto;
  FUserAgent := 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36';

  AutoDetectVLCPath;

  if not (csDesigning in ComponentState) then
  begin
    Initialize;
  end;
end;

destructor TCustomVLCPlayer.Destroy;
begin
  Stop;

  if Assigned(FMediaPlayer) then
  begin
    libvlc_media_player_release(FMediaPlayer);
    FMediaPlayer := nil;
  end;

  if Assigned(FMedia) then
  begin
    libvlc_media_release(FMedia);
    FMedia := nil;
  end;

  if Assigned(FInstance) then
  begin
    libvlc_release(FInstance);
    FInstance := nil;
  end;

  if FLibVLC <> 0 then
  begin
    FreeLibrary(FLibVLC);
    FLibVLC := 0;
  end;

  inherited Destroy;
end;

function TCustomVLCPlayer.CheckVLCFilesExist: Boolean;
begin
  Result := False;

  if FVLCPath = '' then
  begin
    FLastError := 'VLC path is empty';
    Exit;
  end;

  var LibPath := IncludeTrailingPathDelimiter(FVLCPath) + LIBVLC_DLL;
  if not FileExists(LibPath) then
  begin
    FLastError := 'File not found: ' + LibPath;
    Exit;
  end;

  var CorePath := IncludeTrailingPathDelimiter(FVLCPath) + 'libvlccore.dll';
  if not FileExists(CorePath) then
  begin
    FLastError := 'File not found: ' + CorePath;
    Exit;
  end;

  var PluginsPath := IncludeTrailingPathDelimiter(FVLCPath) + 'plugins\';
  if not DirectoryExists(PluginsPath) then
  begin
    FLastError := 'Plugins directory not found: ' + PluginsPath;
    Exit;
  end;

  Result := True;
end;

function TCustomVLCPlayer.GetVLCVersionInfo: string;
var
  FileName: string;
  VerInfoSize: DWORD;
  VerInfo: Pointer;
  VerValueSize: DWORD;
  VerValue: PVSFixedFileInfo;
  Dummy: DWORD;
begin
  Result := 'Unknown';

  if FVLCPath = '' then
    Exit;

  FileName := IncludeTrailingPathDelimiter(FVLCPath) + LIBVLC_DLL;

  if not FileExists(FileName) then
    Exit;

  VerInfoSize := GetFileVersionInfoSize(PChar(FileName), Dummy);
  if VerInfoSize = 0 then
    Exit;

  GetMem(VerInfo, VerInfoSize);
  try
    if GetFileVersionInfo(PChar(FileName), 0, VerInfoSize, VerInfo) then
    begin
      if VerQueryValue(VerInfo, '\', Pointer(VerValue), VerValueSize) then
      begin
        Result := Format('%d.%d.%d.%d', [
          VerValue.dwFileVersionMS shr 16,
          VerValue.dwFileVersionMS and $FFFF,
          VerValue.dwFileVersionLS shr 16,
          VerValue.dwFileVersionLS and $FFFF
        ]);
      end;
    end;
  finally
    FreeMem(VerInfo, VerInfoSize);
  end;
end;

function TCustomVLCPlayer.GetDebugInfo: string;
begin
  Result := 'VLC Debug Information:' + sLineBreak +
            '=====================' + sLineBreak +
            'VLC Path: ' + FVLCPath + sLineBreak +
            'VLC Initialized: ' + BoolToStr(FVLCInitialized, True) + sLineBreak +
            'Last Error: ' + FLastError + sLineBreak +
            'Library Loaded: ' + BoolToStr(FLibVLC <> 0, True) + sLineBreak +
            'Files Exist: ' + BoolToStr(CheckVLCFilesExist, True) + sLineBreak;

  if CheckVLCFilesExist then
    Result := Result + 'VLC Version: ' + GetVLCVersionInfo + sLineBreak;
end;

function TCustomVLCPlayer.TestVLCInstallation: Boolean;
begin
  Result := False;

  if not CheckVLCFilesExist then
  begin
    FLastError := 'VLC files not found: ' + FLastError;
    Exit;
  end;

  if FLibVLC = 0 then
  begin
    if not LoadLibVLC then
    begin
      FLastError := 'Failed to load VLC library: ' + FLastError;
      Exit;
    end;
  end;

  if not FVLCInitialized then
  begin
    if not InitializeVLC then
    begin
      FLastError := 'Failed to initialize VLC: ' + FLastError;
      Exit;
    end;
  end;

  Result := FVLCInitialized;
end;

procedure TCustomVLCPlayer.AutoDetectVLCPath;
var
  AppPath, TestPath: string;
  PossiblePaths: TArray<string>;
  Path: string;
begin
  AppPath := ExtractFilePath(ParamStr(0));

  PossiblePaths := [
    AppPath,
    AppPath + 'vlc\',
    AppPath + 'VLC\',
    AppPath + 'libvlc\',
    'C:\Program Files\VideoLAN\VLC\',
    'C:\Program Files (x86)\VideoLAN\VLC\',
    GetEnvironmentVariable('PROGRAMFILES') + '\VideoLAN\VLC\',
    GetEnvironmentVariable('PROGRAMFILES(X86)') + '\VideoLAN\VLC\'
  ];

  FVLCPath := '';
  for Path in PossiblePaths do
  begin
    TestPath := IncludeTrailingPathDelimiter(Path);
    if FileExists(TestPath + LIBVLC_DLL) then
    begin
      FVLCPath := TestPath;
      FLastError := 'VLC found at: ' + FVLCPath;
      Break;
    end;
  end;

  if FVLCPath = '' then
    FLastError := 'VLC not found in any standard location';
end;

function TCustomVLCPlayer.ExtractBaseURL(const URL: string): string;
var
  PosSlash: Integer;
begin
  Result := URL;
  PosSlash := LastDelimiter('/', URL);
  if PosSlash > 0 then
    Result := Copy(URL, 1, PosSlash);
end;

function TCustomVLCPlayer.ResolveRelativeURL(const BaseURL, RelativeURL: string): string;
begin
  if (RelativeURL.StartsWith('http://')) or (RelativeURL.StartsWith('https://')) then
    Result := RelativeURL
  else if RelativeURL.StartsWith('/') then
  begin
    // Абсолютный путь относительно домена
    if BaseURL.Contains('://') then
    begin
      var ProtocolEnd := Pos('://', BaseURL) + 3;
      var DomainEnd := PosEx('/', BaseURL, ProtocolEnd);
      if DomainEnd = 0 then DomainEnd := Length(BaseURL) + 1;
      Result := Copy(BaseURL, 1, DomainEnd - 1) + RelativeURL;
    end
    else
      Result := BaseURL + Copy(RelativeURL, 2, MaxInt);
  end
  else
    // Относительный путь
    Result := BaseURL + RelativeURL;
end;

function TCustomVLCPlayer.DownloadContent(const URL: string): string;
var
  HttpClient: THTTPClient;
  Response: IHTTPResponse;
begin
  Result := '';
  try
    HttpClient := THTTPClient.Create;
    try
      HttpClient.UserAgent := FUserAgent;
      HttpClient.ConnectionTimeout := 10000;
      HttpClient.ResponseTimeout := 15000;

      Response := HttpClient.Get(URL);
      if Response.StatusCode = 200 then
        Result := Response.ContentAsString(TEncoding.UTF8)
      else
        FLastError := 'HTTP Error: ' + IntToStr(Response.StatusCode);
    finally
      HttpClient.Free;
    end;
  except
    on E: Exception do
    begin
      FLastError := 'Download error: ' + E.Message;
    end;
  end;
end;

function TCustomVLCPlayer.FixM3U8Links(const Content, BaseURL: string): string;
var
  Lines: TArray<string>;
  I: Integer;
  Line: string;
  FixedContent: TStringList;
begin
  Lines := Content.Split([sLineBreak]);
  FixedContent := TStringList.Create;
  try
    for I := 0 to High(Lines) do
    begin
      Line := Lines[I];

      // Игнорируем комментарии и метаданные HLS
      if (Line.StartsWith('#')) or (Line.Trim = '') then
      begin
        FixedContent.Add(Line);
        Continue;
      end;

      // Это URL - обрабатываем относительные ссылки
      if not (Line.StartsWith('http://') or Line.StartsWith('https://') or Line.StartsWith('rtmp://') or Line.StartsWith('rtsp://')) then
      begin
        // Относительный URL - преобразуем в абсолютный
        Line := ResolveRelativeURL(BaseURL, Line);
      end;

      FixedContent.Add(Line);
    end;

    Result := FixedContent.Text;
  finally
    FixedContent.Free;
  end;
end;

function TCustomVLCPlayer.FixSMILLinks(const Content, BaseURL: string): string;
var
  Lines: TArray<string>;
  I: Integer;
  Line: string;
  FixedContent: TStringList;
begin
  Lines := Content.Split([sLineBreak]);
  FixedContent := TStringList.Create;
  try
    for I := 0 to High(Lines) do
    begin
      Line := Lines[I];

      if Line.Contains('src="') or Line.Contains('href="') then
      begin
        var SrcPos := Pos('src="', Line);
        if SrcPos > 0 then
        begin
          var StartPos := SrcPos + 5;
          var EndPos := PosEx('"', Line, StartPos);
          if EndPos > StartPos then
          begin
            var OldURL := Copy(Line, StartPos, EndPos - StartPos);
            var NewURL := ResolveRelativeURL(BaseURL, OldURL);
            Line := StringReplace(Line, OldURL, NewURL, []);
          end;
        end;

        var HrefPos := Pos('href="', Line);
        if HrefPos > 0 then
        begin
          var StartPos := HrefPos + 6;
          var EndPos := PosEx('"', Line, StartPos);
          if EndPos > StartPos then
          begin
            var OldURL := Copy(Line, StartPos, EndPos - StartPos);
            var NewURL := ResolveRelativeURL(BaseURL, OldURL);
            Line := StringReplace(Line, OldURL, NewURL, []);
          end;
        end;
      end;

      FixedContent.Add(Line);
    end;

    Result := FixedContent.Text;
  finally
    FixedContent.Free;
  end;
end;

function TCustomVLCPlayer.ProcessHLSContent(const URL: string): string;
var
  Content: string;
  TempFile: string;
  TempDir: string;
begin
  Result := URL; // По умолчанию возвращаем оригинальный URL

  try
    // Скачиваем HLS плейлист
    Content := DownloadContent(URL);
    if Content = '' then
    begin
      FLastError := 'Failed to download HLS content';
      Exit;
    end;

    // Извлекаем базовый URL
    FBaseURL := ExtractBaseURL(URL);

    // Исправляем относительные ссылки в M3U8
    Content := FixM3U8Links(Content, FBaseURL);

    // Сохраняем исправленный контент во временный файл
    TempDir := GetEnvironmentVariable('TEMP');
    TempFile := IncludeTrailingPathDelimiter(TempDir) +
                'hls_fixed_' + IntToStr(GetTickCount) + '.m3u8';

    TFile.WriteAllText(TempFile, Content, TEncoding.UTF8);

    // Возвращаем путь к временному файлу
    Result := 'file:///' + StringReplace(TempFile, '\', '/', [rfReplaceAll]);

  except
    on E: Exception do
    begin
      FLastError := 'HLS processing error: ' + E.Message;
      Result := URL;
    end;
  end;
end;

function TCustomVLCPlayer.ProcessSMILContent(const URL: string): string;
var
  Content: string;
  TempFile: string;
  TempDir: string;
begin
  Result := URL;

  try
    Content := DownloadContent(URL);
    if Content = '' then
    begin
      FLastError := 'Failed to download SMIL content';
      Exit;
    end;

    FBaseURL := ExtractBaseURL(URL);
    Content := FixSMILLinks(Content, FBaseURL);

    TempDir := GetEnvironmentVariable('TEMP');
    TempFile := IncludeTrailingPathDelimiter(TempDir) +
                'smil_fixed_' + IntToStr(GetTickCount) + '.smil';

    TFile.WriteAllText(TempFile, Content, TEncoding.UTF8);

    Result := 'file:///' + StringReplace(TempFile, '\', '/', [rfReplaceAll]);

  except
    on E: Exception do
    begin
      FLastError := 'SMIL processing error: ' + E.Message;
      Result := URL;
    end;
  end;
end;

procedure TCustomVLCPlayer.SetVLCPath(const Value: string);
begin
  if FVLCPath <> Value then
  begin
    FVLCPath := Value;
    if FVLCInitialized then
    begin
      Stop;
      AutoDetectVLCPath;
      Initialize;
    end;
  end;
end;

procedure TCustomVLCPlayer.SetNetworkCaching(const Value: Integer);
begin
  if FNetworkCaching <> Value then
  begin
    FNetworkCaching := Value;
  end;
end;

procedure TCustomVLCPlayer.SetStreamType(const Value: TVLCStreamType);
begin
  if FStreamType <> Value then
  begin
    FStreamType := Value;
  end;
end;

function TCustomVLCPlayer.LoadLibVLC: Boolean;
var
  FullPath: string;
  OldCurrentDir: string;
  PluginsPath: string;
begin
  Result := False;

  if FVLCInitialized then
  begin
    Result := True;
    Exit;
  end;

  if not CheckVLCFilesExist then
  begin
    FLastError := 'VLC files not found: ' + FLastError;
    Exit;
  end;

  FullPath := IncludeTrailingPathDelimiter(FVLCPath) + LIBVLC_DLL;
  OldCurrentDir := GetCurrentDir;

  try
    SetCurrentDir(FVLCPath);

    PluginsPath := FVLCPath + 'plugins\';
    SetEnvironmentVariable('VLC_PLUGIN_PATH', PChar(PluginsPath));

    FLibVLC := LoadLibrary(PChar(FullPath));

    if FLibVLC = 0 then
    begin
      var LastErrorCode := GetLastError;
//      FLastError := Format('Cannot load %s. Error code: %d (%s)',
//        [FullPath, LastErrorCode, SysErrorMessage(LastErrorCode)]);
      Exit;
    end;

    LoadVLCFunctions;

    Result := True;

  finally
    SetCurrentDir(OldCurrentDir);
  end;
end;

procedure TCustomVLCPlayer.LoadVLCFunctions;
begin
  @libvlc_new := GetProcAddress(FLibVLC, 'libvlc_new');
  @libvlc_release := GetProcAddress(FLibVLC, 'libvlc_release');
  @libvlc_media_new_location := GetProcAddress(FLibVLC, 'libvlc_media_new_location');
  @libvlc_media_new_path := GetProcAddress(FLibVLC, 'libvlc_media_new_path');
  @libvlc_media_release := GetProcAddress(FLibVLC, 'libvlc_media_release');
  @libvlc_media_player_new_from_media := GetProcAddress(FLibVLC, 'libvlc_media_player_new_from_media');
  @libvlc_media_player_release := GetProcAddress(FLibVLC, 'libvlc_media_player_release');
  @libvlc_media_player_set_hwnd := GetProcAddress(FLibVLC, 'libvlc_media_player_set_hwnd');
  @libvlc_media_player_play := GetProcAddress(FLibVLC, 'libvlc_media_player_play');
  @libvlc_media_player_pause := GetProcAddress(FLibVLC, 'libvlc_media_player_pause');
  @libvlc_media_player_stop := GetProcAddress(FLibVLC, 'libvlc_media_player_stop');
  @libvlc_media_player_set_pause := GetProcAddress(FLibVLC, 'libvlc_media_player_set_pause');
  @libvlc_media_player_is_playing := GetProcAddress(FLibVLC, 'libvlc_media_player_is_playing');
  @libvlc_media_player_get_position := GetProcAddress(FLibVLC, 'libvlc_media_player_get_position');
  @libvlc_media_player_set_position := GetProcAddress(FLibVLC, 'libvlc_media_player_set_position');
  @libvlc_media_player_get_time := GetProcAddress(FLibVLC, 'libvlc_media_player_get_time');
  @libvlc_media_player_set_time := GetProcAddress(FLibVLC, 'libvlc_media_player_set_time');
  @libvlc_audio_set_volume := GetProcAddress(FLibVLC, 'libvlc_audio_set_volume');
  @libvlc_audio_get_volume := GetProcAddress(FLibVLC, 'libvlc_audio_get_volume');
  @libvlc_media_player_get_length := GetProcAddress(FLibVLC, 'libvlc_media_player_get_length');
  @libvlc_media_player_will_play := GetProcAddress(FLibVLC, 'libvlc_media_player_will_play');
  @libvlc_media_add_option := GetProcAddress(FLibVLC, 'libvlc_media_add_option');
  @libvlc_media_parse := GetProcAddress(FLibVLC, 'libvlc_media_parse');

  if not Assigned(libvlc_new) then
  begin
    FLastError := 'Required VLC functions not found in library';
    Exit;
  end;
end;

function TCustomVLCPlayer.InitializeVLC: Boolean;
var
  Args: array of PAnsiChar;
  ArgCount: Integer;
  PluginsPath: string;
begin
  Result := False;

  if FVLCInitialized then
  begin
    Result := True;
    Exit;
  end;

  if FLibVLC = 0 then
  begin
    FLastError := 'VLC library not loaded';
    Exit;
  end;

  if not Assigned(libvlc_new) then
  begin
    FLastError := 'VLC functions not properly loaded';
    Exit;
  end;

  try
    ArgCount := 0;
    SetLength(Args, 10);

    Args[ArgCount] := PAnsiChar('--intf=dummy'); Inc(ArgCount);
    Args[ArgCount] := PAnsiChar('--no-video-title-show'); Inc(ArgCount);
    Args[ArgCount] := PAnsiChar('--no-stats'); Inc(ArgCount);

    if FVLCPath <> '' then
    begin
      PluginsPath := '--plugin-path=' + FVLCPath + 'plugins';
      Args[ArgCount] := PAnsiChar(AnsiString(PluginsPath)); Inc(ArgCount);
    end;

    Args[ArgCount] := nil;

    FInstance := libvlc_new(ArgCount, @Args[0]);

    if not Assigned(FInstance) then
    begin
      FLastError := 'libvlc_new returned nil - cannot create VLC instance';

      SetLength(Args, 2);
      Args[0] := PAnsiChar('--intf=dummy');
      Args[1] := nil;
      FInstance := libvlc_new(1, @Args[0]);

      if not Assigned(FInstance) then
      begin
        FLastError := 'Failed to create VLC instance even with minimal arguments';
        Exit;
      end;
    end;

    FVLCInitialized := True;
    FLastError := 'VLC successfully initialized';
    Result := True;

  except
    on E: Exception do
    begin
      FLastError := 'VLC initialization exception: ' + E.Message;
      FVLCInitialized := False;
    end;
  end;
end;

function TCustomVLCPlayer.Initialize: Boolean;
begin
  Result := False;

  if FVLCInitialized then
  begin
    Result := True;
    Exit;
  end;

  try
    if not CheckVLCFilesExist then
    begin
      FLastError := 'VLC files check failed: ' + FLastError;
      Exit;
    end;

    if not LoadLibVLC then
    begin
      FLastError := 'VLC library load failed: ' + FLastError;
      Exit;
    end;

    if not InitializeVLC then
    begin
      FLastError := 'VLC instance creation failed: ' + FLastError;
      Exit;
    end;

    Result := True;

  except
    on E: Exception do
    begin
      FLastError := 'Initialization exception: ' + E.Message;
    end;
  end;
end;

function TCustomVLCPlayer.DetectStreamType(const URL: string): TVLCStreamType;
var
  LowerURL: string;
begin
  LowerURL := LowerCase(URL);

  if LowerURL.Contains('.m3u8') or LowerURL.Contains('/hls/') or LowerURL.Contains('hls_') then
    Result := stHLS
  else if LowerURL.Contains('.smil') or LowerURL.Contains('/smil:') then
    Result := stSMIL
  else if LowerURL.StartsWith('mms://') or LowerURL.StartsWith('mmst://') or LowerURL.StartsWith('mmsh://') then
    Result := stMMS
  else if LowerURL.StartsWith('rtmp://') or LowerURL.Contains('/rtmp/') then
    Result := stRTMP
  else if LowerURL.StartsWith('rtsp://') then
    Result := stRTSP
  else if LowerURL.StartsWith('udp://') or LowerURL.StartsWith('udp://@') then
    Result := stUDP
  else if LowerURL.StartsWith('rtp://') then
    Result := stRTP
  else if LowerURL.StartsWith('http://') or LowerURL.StartsWith('https://') then
    Result := stHTTP
  else if FileExists(URL) then
    Result := stFile
  else
    Result := stAuto;
end;

function TCustomVLCPlayer.BuildVLCOptions(const URL: string; StreamType: TVLCStreamType): TArray<string>;
var
  Options: TStringList;
  DetectedType: TVLCStreamType;
begin
  Options := TStringList.Create;
  try
    if StreamType = stAuto then
      DetectedType := DetectStreamType(URL)
    else
      DetectedType := StreamType;

    Options.Add(':network-caching=' + IntToStr(FNetworkCaching));
    Options.Add(':live-caching=' + IntToStr(FNetworkCaching));
    Options.Add(':file-caching=' + IntToStr(FNetworkCaching));
    Options.Add(':sout-mux-caching=' + IntToStr(FNetworkCaching));
    Options.Add(':clock-jitter=0');
    Options.Add(':clock-synchro=0');

    case DetectedType of
      stHLS:
        begin
          Options.Add(':hls-segment-threads=3');
          Options.Add(':hls-timeout=30');
          Options.Add(':hls-bitrate-adaptive');
          Options.Add(':http-reconnect=true');
          Options.Add(':http-continuous');
          Options.Add(':hls-prefer-native');
        end;

      stSMIL:
        begin
          Options.Add(':smil-active-item');
          Options.Add(':smil-forward');
          Options.Add(':sout-smil-timeout=30');
          Options.Add(':smil-attachments=all');
          Options.Add(':no-smil-index');
        end;

      stMMS:
        begin
          Options.Add(':mms-timeout=30');
          Options.Add(':mms-caching=2000');
          Options.Add(':mmsh-rate=10000000');
        end;

      stRTMP:
        begin
          Options.Add(':rtmp-live');
          Options.Add(':rtmp-timeout=30');
          Options.Add(':rtmp-swfverify');
          Options.Add(':rtmp-buffer=3000');
        end;

      stRTSP:
        begin
          Options.Add(':rtsp-tcp');
          Options.Add(':rtsp-timeout=30');
          Options.Add(':rtsp-http-port=80');
          Options.Add(':rtsp-http-caching=3000');
        end;

      stUDP:
        begin
          Options.Add(':udp-timeout=60000000');
          Options.Add(':udp-caching=1000');
        end;

      stRTP:
        begin
          Options.Add(':rtp-max-dropout=1000');
          Options.Add(':rtp-max-misorder=1000');
          Options.Add(':rtp-sync=0');
        end;

      stHTTP:
        begin
          Options.Add(':http-user-agent="' + FUserAgent + '"');
          Options.Add(':http-referrer=""');
          Options.Add(':http-forward-cookies');
          Options.Add(':http-continuous');
        end;
    end;

    Options.Add(':avcodec-hw=any');
    Options.Add(':drop-late-frames');
    Options.Add(':skip-frames');
    Options.Add(':codec=avcodec,none');

    Result := Options.ToStringArray;

  finally
    Options.Free;
  end;
end;

function TCustomVLCPlayer.CreateMediaWithOptions(const URL: string; StreamType: TVLCStreamType): Pointer;
var
  Options: TArray<string>;
  MRL: UTF8String;
  i: Integer;
  ActualURL: string;
begin
  Result := nil;

  if not FVLCInitialized then
    Exit;

  // Обрабатываем HLS и SMIL контент
  ActualURL := URL;
  if (StreamType = stHLS) or ((StreamType = stAuto) and (DetectStreamType(URL) = stHLS)) then
  begin
    ActualURL := ProcessHLSContent(URL);
  end
  else if (StreamType = stSMIL) or ((StreamType = stAuto) and (DetectStreamType(URL) = stSMIL)) then
  begin
    ActualURL := ProcessSMILContent(URL);
  end;

  // Создаем media объект
  MRL := UTF8String(ActualURL);
  if StreamType = stFile then
    Result := libvlc_media_new_path(FInstance, PAnsiChar(MRL))
  else
    Result := libvlc_media_new_location(FInstance, PAnsiChar(MRL));

  if not Assigned(Result) then
    Exit;

  // Добавляем опции
  Options := BuildVLCOptions(URL, StreamType);
  for i := 0 to High(Options) do
  begin
    if Options[i] <> '' then
      libvlc_media_add_option(Result, PAnsiChar(UTF8String(Options[i])));
  end;

  libvlc_media_parse(Result);
end;

function TCustomVLCPlayer.PlayURL(const URL: string): Boolean;
begin
  Result := PlayURL(URL, FStreamType);
end;

function TCustomVLCPlayer.PlayURL(const URL: string; StreamType: TVLCStreamType): Boolean;
begin
  Result := False;
  CheckVLCInitialized;

  if not FVLCInitialized then
    Exit;

  Stop;

  if Assigned(FMediaPlayer) then
  begin
    libvlc_media_player_release(FMediaPlayer);
    FMediaPlayer := nil;
  end;
  if Assigned(FMedia) then
  begin
    libvlc_media_release(FMedia);
    FMedia := nil;
  end;

  FMedia := CreateMediaWithOptions(URL, StreamType);
  if not Assigned(FMedia) then
  begin
    FLastError := 'Failed to create media for URL: ' + URL;
    Exit;
  end;

  FMediaPlayer := libvlc_media_player_new_from_media(FMedia);
  if not Assigned(FMediaPlayer) then
  begin
    libvlc_media_release(FMedia);
    FMedia := nil;
    FLastError := 'Failed to create media player';
    Exit;
  end;

  if FHandle <> 0 then
    libvlc_media_player_set_hwnd(FMediaPlayer, FHandle);

  libvlc_audio_set_volume(FMediaPlayer, FVolume);

  Play;
  Result := True;
end;

function TCustomVLCPlayer.PlayFile(const FileName: string): Boolean;
begin
  Result := PlayURL(FileName, stFile);
end;

function TCustomVLCPlayer.PlayIPTV(const URL: string): Boolean;
begin
  Result := PlayURL(URL, stAuto);
end;

function TCustomVLCPlayer.PlayIPTV(const URL: string; StreamType: TVLCStreamType): Boolean;
begin
  Result := PlayURL(URL, StreamType);
end;

function TCustomVLCPlayer.PlayHLS(const URL: string): Boolean;
begin
  Result := PlayURL(URL, stHLS);
end;

function TCustomVLCPlayer.PlaySMIL(const URL: string): Boolean;
begin
  Result := PlayURL(URL, stSMIL);
end;

function TCustomVLCPlayer.PlayMMS(const URL: string): Boolean;
begin
  Result := PlayURL(URL, stMMS);
end;

function TCustomVLCPlayer.PlayRTMP(const URL: string): Boolean;
begin
  Result := PlayURL(URL, stRTMP);
end;

function TCustomVLCPlayer.PlayRTSP(const URL: string): Boolean;
begin
  Result := PlayURL(URL, stRTSP);
end;

function TCustomVLCPlayer.PlayUDP(const URL: string): Boolean;
begin
  Result := PlayURL(URL, stUDP);
end;

function TCustomVLCPlayer.PlayRTP(const URL: string): Boolean;
begin
  Result := PlayURL(URL, stRTP);
end;

procedure TCustomVLCPlayer.Play;
begin
  CheckVLCInitialized;
  if FVLCInitialized and Assigned(FMediaPlayer) then
  begin
    libvlc_media_player_play(FMediaPlayer);
    FIsPlaying := True;
    DoPlay;
  end;
end;

procedure TCustomVLCPlayer.Pause;
begin
  if FVLCInitialized and Assigned(FMediaPlayer) then
  begin
    libvlc_media_player_pause(FMediaPlayer);
    FIsPlaying := False;
    DoPause;
  end;
end;

procedure TCustomVLCPlayer.Stop;
begin
  if FVLCInitialized and Assigned(FMediaPlayer) then
  begin
    libvlc_media_player_stop(FMediaPlayer);
    FIsPlaying := False;
    DoStop;
  end;
end;

procedure TCustomVLCPlayer.SetHandle(const Value: THandle);
begin
  if FHandle <> Value then
  begin
    FHandle := Value;
    if FVLCInitialized and Assigned(FMediaPlayer) and (FHandle <> 0) then
      libvlc_media_player_set_hwnd(FMediaPlayer, FHandle);
  end;
end;

procedure TCustomVLCPlayer.SetVolume(const Value: Integer);
begin
  if FVolume <> Value then
  begin
    FVolume := Value;
    if FVLCInitialized and Assigned(FMediaPlayer) then
      libvlc_audio_set_volume(FMediaPlayer, FVolume);
  end;
end;

function TCustomVLCPlayer.GetPosition: Single;
begin
  if FVLCInitialized and Assigned(FMediaPlayer) then
    Result := libvlc_media_player_get_position(FMediaPlayer)
  else
    Result := 0;
end;

procedure TCustomVLCPlayer.SetPosition(const Value: Single);
begin
  if FVLCInitialized and Assigned(FMediaPlayer) then
    libvlc_media_player_set_position(FMediaPlayer, Value);
end;

function TCustomVLCPlayer.GetTime: Int64;
begin
  if FVLCInitialized and Assigned(FMediaPlayer) then
    Result := libvlc_media_player_get_time(FMediaPlayer)
  else
    Result := 0;
end;

procedure TCustomVLCPlayer.SetTime(const Value: Int64);
begin
  if FVLCInitialized and Assigned(FMediaPlayer) then
    libvlc_media_player_set_time(FMediaPlayer, Value);
end;

function TCustomVLCPlayer.GetLength: Int64;
begin
  if FVLCInitialized and Assigned(FMediaPlayer) then
    Result := libvlc_media_player_get_length(FMediaPlayer)
  else
    Result := 0;
end;

function TCustomVLCPlayer.GetIsPlaying: Boolean;
begin
  if FVLCInitialized and Assigned(FMediaPlayer) then
    Result := libvlc_media_player_is_playing(FMediaPlayer) <> 0
  else
    Result := False;
end;

function TCustomVLCPlayer.GetVLCInitialized: Boolean;
begin
  Result := FVLCInitialized;
end;

function TCustomVLCPlayer.GetLastError: string;
begin
  Result := FLastError;
end;

procedure TCustomVLCPlayer.CheckVLCInitialized;
begin
  if not FVLCInitialized and not (csDesigning in ComponentState) then
  begin
    if not Initialize then
      raise Exception.Create('VLC not initialized: ' + FLastError);
  end;
end;

procedure TCustomVLCPlayer.DoPlay;
begin
  if Assigned(FOnPlay) then
    FOnPlay(Self);
end;

procedure TCustomVLCPlayer.DoPause;
begin
  if Assigned(FOnPause) then
    FOnPause(Self);
end;

procedure TCustomVLCPlayer.DoStop;
begin
  if Assigned(FOnStop) then
    FOnStop(Self);
end;

procedure TCustomVLCPlayer.DoEndReached;
begin
  if Assigned(FOnEndReached) then
    FOnEndReached(Self);
end;

procedure TCustomVLCPlayer.DoPositionChanged(Position: Single);
begin
  if Assigned(FOnPositionChanged) then
    FOnPositionChanged(Self, Position);
end;

procedure TCustomVLCPlayer.DoTimeChanged(Time: Int64);
begin
  if Assigned(FOnTimeChanged) then
    FOnTimeChanged(Self, Time);
end;

procedure TCustomVLCPlayer.DoBuffering(CachePercentage: Single);
begin
  if Assigned(FOnBuffering) then
    FOnBuffering(Self, CachePercentage);
end;

end.
