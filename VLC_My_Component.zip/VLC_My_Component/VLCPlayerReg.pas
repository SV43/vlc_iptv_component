unit VLCPlayerReg;

interface

uses
  System.Classes, VLCPlayer;

procedure Register;

implementation

procedure Register;
begin
  RegisterComponents('Video', [TVLCPlayer]);
end;

end.