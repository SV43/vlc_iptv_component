﻿unit IPTVPlayerForm;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes,
  Vcl.Graphics, Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.StdCtrls, Vcl.ExtCtrls,
  Vcl.ComCtrls, System.IniFiles, VLCPlayer;

type
  TIPTVChannel = record
    Name: string;
    URL: string;
    Group: string;
  end;

  TForm2 = class(TForm)
    Panel1: TPanel;
    Splitter1: TSplitter;
    Panel2: TPanel;
    ListBoxChannels: TListBox;
    PanelVideo: TPanel;
    PanelControls: TPanel;
    btnPlay: TButton;
    btnStop: TButton;
    TrackBarVolume: TTrackBar;
    Label1: TLabel;
    ComboBoxGroups: TComboBox;
    Label2: TLabel;
    Label3: TLabel;
    LabelChannelInfo: TLabel;
    btnPause: TButton;
    Label4: TLabel;
    edtChannelName: TEdit;
    edtChannelURL: TEdit;
    btnAddChannel: TButton;
    btnLoadM3U: TButton;
    btnRemoveChannel: TButton;
    Label5: TLabel;
    ComboBoxGroupFilter: TComboBox;
    StatusBar1: TStatusBar;
    Timer1: TTimer;
    Button1: TButton;
    Memo1: TMemo;
    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure ListBoxChannelsDblClick(Sender: TObject);
    procedure btnPlayClick(Sender: TObject);
    procedure btnStopClick(Sender: TObject);
    procedure TrackBarVolumeChange(Sender: TObject);
    procedure ComboBoxGroupsChange(Sender: TObject);
    procedure btnPauseClick(Sender: TObject);
    procedure btnAddChannelClick(Sender: TObject);
    procedure btnLoadM3UClick(Sender: TObject);
    procedure btnRemoveChannelClick(Sender: TObject);
    procedure ComboBoxGroupFilterChange(Sender: TObject);
    procedure Timer1Timer(Sender: TObject);
    procedure ListBoxChannelsClick(Sender: TObject);
    procedure FormResize(Sender: TObject);
    procedure Button1Click(Sender: TObject);
  private
    VLCPlayer: TVLCPlayer;
    Channels: array of TIPTVChannel;
    procedure LoadChannels;
    procedure LoadM3UPlaylist(const FileName: string);
    procedure SaveChannels;
    procedure FilterChannelsByGroup(const GroupName: string);
    procedure PlaySelectedChannel;
    procedure UpdateChannelList;
    procedure UpdateStatus;
    function GetSelectedChannelIndex: Integer;
    procedure VLCPlayerError(Sender: TObject; const ErrorMessage: string);
  public
    { Public declarations }
  end;

var
  Form2: TForm2;

implementation

{$R *.dfm}

procedure TForm2.VLCPlayerError(Sender: TObject; const ErrorMessage: string);
begin
  // Выводим ошибку в Memo или StatusBar
  Memo1.Lines.Add('ОШИБКА VLC: ' + ErrorMessage);
  StatusBar1.Panels[0].Text := 'Ошибка: ' + ErrorMessage;

  // Или показываем сообщение
  // ShowMessage('Ошибка VLC: ' + ErrorMessage);
end;

procedure TForm2.FormCreate(Sender: TObject);
begin
  // Создаем VLC плеер
  VLCPlayer := TVLCPlayer.Create(Self);
  VLCPlayer.Handle := PanelVideo.Handle;
  VLCPlayer.Volume := TrackBarVolume.Position;
  VLCPlayer.VLCPath :='C:\Delphi\Source\2025\VLC_My_Component\Win32\Debug\';



  // Проверяем инициализацию
  if not VLCPlayer.VLCInitialized then
  begin
    ShowMessage('VLC не инициализирован: ' + VLCPlayer.LastError);
  end
  else
  begin
    ShowMessage('VLC успешно инициализирован');
  end;

  // Настраиваем интерфейс
  PanelVideo.Color := clBlack;
  LabelChannelInfo.Caption := 'Выберите канал для воспроизведения';
  StatusBar1.Panels[0].Text := 'Готов к работе';

  // Загружаем каналы
  LoadChannels;
  
  // Обновляем статус
  UpdateStatus;
end;

procedure TForm2.FormDestroy(Sender: TObject);
begin
  SaveChannels;
  VLCPlayer.Free;
end;

procedure TForm2.FormResize(Sender: TObject);
begin
  // Подстраиваем размеры при изменении формы
  PanelVideo.Width := Panel2.Width - 20;
  PanelVideo.Height := Panel2.Height - 80;
end;

procedure TForm2.LoadChannels;
var
  IniFile: TIniFile;
  i, Count: Integer;
  Channel: TIPTVChannel;
begin
  // Загрузка каналов из INI файла
  IniFile := TIniFile.Create(ChangeFileExt(ParamStr(0), '.ini'));
  try
    Count := IniFile.ReadInteger('Channels', 'Count', 0);
    
    if Count = 0 then
    begin
      // Загрузка тестовых IPTV каналов по умолчанию
      SetLength(Channels, 6);
      
      Channels[0].Name := 'Тестовый MP4 (демо)';
      Channels[0].URL := 'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4';
      Channels[0].Group := 'Тестовые';
      
      Channels[1].Name := 'Тестовый HLS (демо)';
      Channels[1].URL := 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8';
      Channels[1].Group := 'Тестовые';
      
      Channels[2].Name := 'UDP Multicast 1';
      Channels[2].URL := 'udp://@239.1.1.1:1234';
      Channels[2].Group := 'UDP';
      
      Channels[3].Name := 'UDP Multicast 2';
      Channels[3].URL := 'udp://@239.1.1.2:1234';
      Channels[3].Group := 'UDP';
      
      Channels[4].Name := 'HTTP Stream';
      Channels[4].URL := 'http://livestream.example.com/stream';
      Channels[4].Group := 'HTTP';
      
      Channels[5].Name := 'RTSP Camera';
      Channels[5].URL := 'rtsp://cam.example.com:554/live.sdp';
      Channels[5].Group := 'RTSP';
    end
    else
    begin
      // Загрузка из INI файла
      SetLength(Channels, Count);
      for i := 0 to Count - 1 do
      begin
        Channels[i].Name := IniFile.ReadString('Channel' + IntToStr(i), 'Name', '');
        Channels[i].URL := IniFile.ReadString('Channel' + IntToStr(i), 'URL', '');
        Channels[i].Group := IniFile.ReadString('Channel' + IntToStr(i), 'Group', 'Общие');
      end;
    end;
    
  finally
    IniFile.Free;
  end;
  
  // Заполняем группы
  ComboBoxGroups.Items.Clear;
  ComboBoxGroupFilter.Items.Clear;
  
  ComboBoxGroups.Items.Add('Общие');
  ComboBoxGroups.Items.Add('Тестовые');
  ComboBoxGroups.Items.Add('UDP');
  ComboBoxGroups.Items.Add('RTP');
  ComboBoxGroups.Items.Add('HTTP');
  ComboBoxGroups.Items.Add('RTSP');
  ComboBoxGroups.Items.Add('Другие');
  ComboBoxGroups.ItemIndex := 0;
  
  ComboBoxGroupFilter.Items.Add('Все группы');
  ComboBoxGroupFilter.Items.Add('Общие');
  ComboBoxGroupFilter.Items.Add('Тестовые');
  ComboBoxGroupFilter.Items.Add('UDP');
  ComboBoxGroupFilter.Items.Add('RTP');
  ComboBoxGroupFilter.Items.Add('HTTP');
  ComboBoxGroupFilter.Items.Add('RTSP');
  ComboBoxGroupFilter.Items.Add('Другие');
  ComboBoxGroupFilter.ItemIndex := 0;
  
  FilterChannelsByGroup('Все группы');
end;

procedure TForm2.SaveChannels;
var
  IniFile: TIniFile;
  i: Integer;
begin
  // Сохранение каналов в INI файл
  IniFile := TIniFile.Create(ChangeFileExt(ParamStr(0), '.ini'));
  try
    IniFile.WriteInteger('Channels', 'Count', Length(Channels));
    
    for i := 0 to High(Channels) do
    begin
      IniFile.WriteString('Channel' + IntToStr(i), 'Name', Channels[i].Name);
      IniFile.WriteString('Channel' + IntToStr(i), 'URL', Channels[i].URL);
      IniFile.WriteString('Channel' + IntToStr(i), 'Group', Channels[i].Group);
    end;
    
  finally
    IniFile.Free;
  end;
end;

procedure TForm2.LoadM3UPlaylist(const FileName: string);
var
  M3UFile: TStringList;
  i: Integer;
  Line, GroupName: string;
  Channel: TIPTVChannel;
begin
  if not FileExists(FileName) then
  begin
    ShowMessage('Файл не найден: ' + FileName);
    Exit;
  end;
  
  M3UFile := TStringList.Create;
  try
    M3UFile.LoadFromFile(FileName);
    
    i := 0;
    while i < M3UFile.Count do
    begin
      Line := Trim(M3UFile[i]);
      
      if Pos('#EXTINF:', Line) = 1 then
      begin
        // Это информация о канале
        Channel.Name := Copy(Line, Pos(',', Line) + 1, Length(Line));
        Channel.Group := 'Импортированные';
        
        // Пытаемся извлечь группу
        if Pos('group-title="', Line) > 0 then
        begin
          GroupName := Copy(Line, Pos('group-title="', Line) + 13, Length(Line));
          GroupName := Copy(GroupName, 1, Pos('"', GroupName) - 1);
          Channel.Group := GroupName;
        end;
        
        // Следующая строка - URL
        if i + 1 < M3UFile.Count then
        begin
          Channel.URL := Trim(M3UFile[i + 1]);
          SetLength(Channels, Length(Channels) + 1);
          Channels[High(Channels)] := Channel;
          Inc(i);
        end;
      end;
      Inc(i);
    end;
    
    FilterChannelsByGroup(ComboBoxGroupFilter.Text);
    ShowMessage('Загружено каналов: ' + IntToStr(Length(Channels)));
    
  finally
    M3UFile.Free;
  end;
end;

procedure TForm2.FilterChannelsByGroup(const GroupName: string);
var
  i: Integer;
begin
  ListBoxChannels.Clear;
  
  for i := 0 to High(Channels) do
  begin
    if (GroupName = 'Все группы') or (Channels[i].Group = GroupName) then
    begin
      ListBoxChannels.Items.Add(Channels[i].Name);
    end;
  end;
  
  if ListBoxChannels.Count > 0 then
    ListBoxChannels.ItemIndex := 0;
    
  UpdateChannelList;
end;

procedure TForm2.UpdateChannelList;
begin
  Label3.Caption := 'Каналы: ' + IntToStr(ListBoxChannels.Count) + ' из ' + IntToStr(Length(Channels));
end;

procedure TForm2.PlaySelectedChannel;
var
  ChannelIndex: Integer;
begin
  ChannelIndex := GetSelectedChannelIndex;
  if ChannelIndex = -1 then Exit;

  if VLCPlayer.PlayIPTV(Channels[ChannelIndex].URL) then
  begin
    LabelChannelInfo.Caption := Format('Сейчас играет: %s (%s)', 
      [Channels[ChannelIndex].Name, Channels[ChannelIndex].Group]);
    StatusBar1.Panels[0].Text := 'Воспроизведение: ' + Channels[ChannelIndex].Name;
  end
  else
  begin
    LabelChannelInfo.Caption := 'Ошибка воспроизведения: ' + Channels[ChannelIndex].Name;
    StatusBar1.Panels[0].Text := 'Ошибка воспроизведения';
  end;
  
  UpdateStatus;
end;

function TForm2.GetSelectedChannelIndex: Integer;
var
  i, VisibleIndex: Integer;
begin
  Result := -1;
  if ListBoxChannels.ItemIndex < 0 then Exit;
  
  VisibleIndex := 0;
  for i := 0 to High(Channels) do
  begin
    if (ComboBoxGroupFilter.Text = 'Все группы') or (Channels[i].Group = ComboBoxGroupFilter.Text) then
    begin
      if VisibleIndex = ListBoxChannels.ItemIndex then
      begin
        Result := i;
        Exit;
      end;
      Inc(VisibleIndex);
    end;
  end;
end;

procedure TForm2.UpdateStatus;
begin
  if not VLCPlayer.VLCInitialized then
  begin
    StatusBar1.Panels[1].Text := 'VLC не инициализирован';
    btnPlay.Enabled := False;
    btnPause.Enabled := False;
    btnStop.Enabled := False;
    Exit;
  end;
  
  if VLCPlayer.IsPlaying then
  begin
    StatusBar1.Panels[1].Text := 'Статус: Воспроизведение';
    btnPlay.Enabled := True;
    btnPause.Enabled := True;
    btnStop.Enabled := True;
  end
  else
  begin
    StatusBar1.Panels[1].Text := 'Статус: Остановлено';
    btnPlay.Enabled := True;
    btnPause.Enabled := False;
    btnStop.Enabled := False;
  end;
end;

// Обработчики событий

procedure TForm2.ListBoxChannelsClick(Sender: TObject);
var
  ChannelIndex: Integer;
begin
  ChannelIndex := GetSelectedChannelIndex;
  if ChannelIndex >= 0 then
  begin
    edtChannelName.Text := Channels[ChannelIndex].Name;
    edtChannelURL.Text := Channels[ChannelIndex].URL;
    ComboBoxGroups.Text := Channels[ChannelIndex].Group;
  end;
end;

procedure TForm2.ListBoxChannelsDblClick(Sender: TObject);
begin
  PlaySelectedChannel;
end;

procedure TForm2.btnPlayClick(Sender: TObject);
begin
  PlaySelectedChannel;
end;

procedure TForm2.btnPauseClick(Sender: TObject);
begin
  VLCPlayer.Pause;
  UpdateStatus;
  StatusBar1.Panels[0].Text := 'Пауза';
end;

procedure TForm2.btnStopClick(Sender: TObject);
begin
  VLCPlayer.Stop;
  UpdateStatus;
  LabelChannelInfo.Caption := 'Воспроизведение остановлено';
  StatusBar1.Panels[0].Text := 'Остановлено';
end;

procedure TForm2.Button1Click(Sender: TObject);
begin
  VLCPlayer.PlaySMIL(edtChannelURL.Text)
end;

procedure TForm2.TrackBarVolumeChange(Sender: TObject);
begin
  VLCPlayer.Volume := TrackBarVolume.Position;
  Label1.Caption := 'Громкость: ' + IntToStr(TrackBarVolume.Position) + '%';
end;

procedure TForm2.ComboBoxGroupsChange(Sender: TObject);
begin
  // Обновляем группу для редактирования
end;

procedure TForm2.ComboBoxGroupFilterChange(Sender: TObject);
begin
  FilterChannelsByGroup(ComboBoxGroupFilter.Text);
end;

procedure TForm2.btnAddChannelClick(Sender: TObject);
var
  NewChannel: TIPTVChannel;
begin
  if (edtChannelName.Text = '') or (edtChannelURL.Text = '') then
  begin
    ShowMessage('Заполните название и URL канала');
    Exit;
  end;
  
  NewChannel.Name := edtChannelName.Text;
  NewChannel.URL := edtChannelURL.Text;
  NewChannel.Group := ComboBoxGroups.Text;
  
  SetLength(Channels, Length(Channels) + 1);
  Channels[High(Channels)] := NewChannel;
  
  FilterChannelsByGroup(ComboBoxGroupFilter.Text);
  SaveChannels;
  
  ShowMessage('Канал добавлен: ' + NewChannel.Name);
end;

procedure TForm2.btnLoadM3UClick(Sender: TObject);
var
  OpenDialog: TOpenDialog;
begin
  OpenDialog := TOpenDialog.Create(Self);
  try
    OpenDialog.Filter := 'M3U плейлисты|*.m3u;*.m3u8|Все файлы|*.*';
    OpenDialog.FilterIndex := 0;
    
    if OpenDialog.Execute then
    begin
      LoadM3UPlaylist(OpenDialog.FileName);
      SaveChannels;
    end;
  finally
    OpenDialog.Free;
  end;
end;

procedure TForm2.btnRemoveChannelClick(Sender: TObject);
var
  ChannelIndex, i: Integer;
begin
  ChannelIndex := GetSelectedChannelIndex;
  if ChannelIndex = -1 then Exit;
  
  if MessageDlg('Удалить канал "' + Channels[ChannelIndex].Name + '"?', 
     mtConfirmation, [mbYes, mbNo], 0) = mrYes then
  begin
    // Удаляем канал из массива
    for i := ChannelIndex to High(Channels) - 1 do
    begin
      Channels[i] := Channels[i + 1];
    end;
    SetLength(Channels, Length(Channels) - 1);
    
    FilterChannelsByGroup(ComboBoxGroupFilter.Text);
    SaveChannels;
    
    ShowMessage('Канал удален');
  end;
end;

procedure TForm2.Timer1Timer(Sender: TObject);
begin
  UpdateStatus;
  
{  // Обновляем информацию о времени воспроизведения
  if VLCPlayer.VLCInitialized and VLCPlayer.IsPlaying then
  begin
    StatusBar1.Panels[2].Text := Format('Время: %s / %s', 
      [FormatDateTime('nn:ss', VLCPlayer.Time / 1000 / 24 / 60 / 60),
       FormatDateTime('nn:ss', VLCPlayer.Length / 1000 / 24 / 60 / 60)]);
  end
  else
  begin
    StatusBar1.Panels[2].Text := '';
  end;      }
end;

end.