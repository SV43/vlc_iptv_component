object Form2: TForm2
  Left = 0
  Top = 0
  Caption = 'IPTV Player - VLC'
  ClientHeight = 600
  ClientWidth = 900
  Color = clBtnFace
  Constraints.MinHeight = 500
  Constraints.MinWidth = 700
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  OnResize = FormResize
  TextHeight = 13
  object Splitter1: TSplitter
    Left = 250
    Top = 0
    Height = 581
    ExplicitLeft = 264
    ExplicitTop = 192
    ExplicitHeight = 100
  end
  object Panel1: TPanel
    Left = 0
    Top = 0
    Width = 250
    Height = 581
    Align = alLeft
    BevelOuter = bvNone
    TabOrder = 0
    object Label2: TLabel
      Left = 8
      Top = 8
      Width = 95
      Height = 13
      Caption = #1060#1080#1083#1100#1090#1088' '#1087#1086' '#1075#1088#1091#1087#1087#1077':'
    end
    object Label3: TLabel
      Left = 8
      Top = 54
      Width = 43
      Height = 13
      Caption = #1050#1072#1085#1072#1083#1099':'
    end
    object Label4: TLabel
      Left = 8
      Top = 320
      Width = 58
      Height = 13
      Caption = #1053#1072#1079#1074#1072#1085#1080#1077':'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = [fsBold]
      ParentFont = False
    end
    object Label5: TLabel
      Left = 8
      Top = 366
      Width = 44
      Height = 13
      Caption = #1043#1088#1091#1087#1087#1072':'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = [fsBold]
      ParentFont = False
    end
    object ComboBoxGroupFilter: TComboBox
      Left = 8
      Top = 27
      Width = 234
      Height = 21
      Style = csDropDownList
      TabOrder = 0
      OnChange = ComboBoxGroupFilterChange
    end
    object ListBoxChannels: TListBox
      Left = 8
      Top = 73
      Width = 234
      Height = 240
      ItemHeight = 13
      TabOrder = 1
      OnClick = ListBoxChannelsClick
      OnDblClick = ListBoxChannelsDblClick
    end
    object edtChannelName: TEdit
      Left = 8
      Top = 339
      Width = 234
      Height = 21
      TabOrder = 2
    end
    object edtChannelURL: TEdit
      Left = 8
      Top = 385
      Width = 234
      Height = 21
      TabOrder = 3
    end
    object btnAddChannel: TButton
      Left = 5
      Top = 458
      Width = 75
      Height = 25
      Caption = #1044#1086#1073#1072#1074#1080#1090#1100
      TabOrder = 5
      OnClick = btnAddChannelClick
    end
    object btnRemoveChannel: TButton
      Left = 86
      Top = 458
      Width = 75
      Height = 25
      Caption = #1059#1076#1072#1083#1080#1090#1100
      TabOrder = 6
      OnClick = btnRemoveChannelClick
    end
    object btnLoadM3U: TButton
      Left = 169
      Top = 458
      Width = 75
      Height = 25
      Caption = #1047#1072#1075#1088#1091#1079#1080#1090#1100' M3U'
      TabOrder = 7
      OnClick = btnLoadM3UClick
    end
    object ComboBoxGroups: TComboBox
      Left = 8
      Top = 431
      Width = 234
      Height = 21
      TabOrder = 4
      OnChange = ComboBoxGroupsChange
    end
  end
  object Panel2: TPanel
    Left = 253
    Top = 0
    Width = 647
    Height = 581
    Align = alClient
    BevelOuter = bvNone
    TabOrder = 1
    object PanelVideo: TPanel
      Left = 14
      Top = 8
      Width = 620
      Height = 400
      BevelOuter = bvNone
      Color = clBlack
      ParentBackground = False
      TabOrder = 0
    end
    object PanelControls: TPanel
      Left = 0
      Top = 436
      Width = 647
      Height = 145
      Align = alBottom
      BevelOuter = bvNone
      TabOrder = 1
      object LabelChannelInfo: TLabel
        Left = 16
        Top = 16
        Width = 197
        Height = 13
        Caption = #1042#1099#1073#1077#1088#1080#1090#1077' '#1082#1072#1085#1072#1083' '#1076#1083#1103' '#1074#1086#1089#1087#1088#1086#1080#1079#1074#1077#1076#1077#1085#1080#1103
      end
      object Label1: TLabel
        Left = 16
        Top = 72
        Width = 53
        Height = 13
        Caption = #1043#1088#1086#1084#1082#1086#1089#1090#1100
      end
      object btnPlay: TButton
        Left = 16
        Top = 40
        Width = 75
        Height = 25
        Caption = #1042#1086#1089#1087#1088#1086#1080#1079#1074#1077#1089#1090#1080
        TabOrder = 0
        OnClick = btnPlayClick
      end
      object btnPause: TButton
        Left = 97
        Top = 40
        Width = 75
        Height = 25
        Caption = #1055#1072#1091#1079#1072
        TabOrder = 1
        OnClick = btnPauseClick
      end
      object btnStop: TButton
        Left = 178
        Top = 40
        Width = 75
        Height = 25
        Caption = #1057#1090#1086#1087
        TabOrder = 2
        OnClick = btnStopClick
      end
      object TrackBarVolume: TTrackBar
        Left = 16
        Top = 91
        Width = 150
        Height = 45
        Max = 100
        Position = 50
        TabOrder = 3
        OnChange = TrackBarVolumeChange
      end
      object Button1: TButton
        Left = 312
        Top = 80
        Width = 75
        Height = 25
        Caption = 'Button1'
        TabOrder = 4
        OnClick = Button1Click
      end
      object Memo1: TMemo
        Left = 440
        Top = 24
        Width = 185
        Height = 89
        Lines.Strings = (
          'Memo1')
        TabOrder = 5
      end
    end
  end
  object StatusBar1: TStatusBar
    Left = 0
    Top = 581
    Width = 900
    Height = 19
    Panels = <
      item
        Width = 200
      end
      item
        Width = 150
      end
      item
        Width = 100
      end>
  end
  object Timer1: TTimer
    OnTimer = Timer1Timer
    Left = 400
    Top = 200
  end
end
