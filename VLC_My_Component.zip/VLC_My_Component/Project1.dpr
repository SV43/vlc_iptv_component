program Project1;

uses
  Vcl.Forms,
  IPTVPlayerForm in 'IPTVPlayerForm.pas' {Form2},
  VLCPlayer in 'VLCPlayer.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.MainFormOnTaskbar := True;
  Application.CreateForm(TForm2, Form2);
  Application.Run;
end.
